class Callable():
    def __init__(self, blocks):
        self.blocks = blocks

    def get_blocks(self):
        return self.blocks